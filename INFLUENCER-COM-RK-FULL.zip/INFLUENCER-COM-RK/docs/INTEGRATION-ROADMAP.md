# Integration roadmap

## Social networks
Use official OAuth authorization-code flows. Request the minimum permissions. Persist provider access/refresh tokens only in a trusted server environment (encrypted at rest). Never ask users to paste passwords. Use official APIs for profile identifiers and metrics. Record `last_synced_at`, the source and the metric timestamp. If a platform does not expose a metric to your app, show “Not available” rather than estimating it.

## Location and matching
Collect creator-selected country/city and optionally a consented approximate service area. Use a reputable geocoding provider for coordinates. Do not expose exact home addresses. Match using campaign category, country/city or radius, audience language, platform, budget and verified metrics. Make ranking explainable and allow brands to sort without a hidden score.

## Collaboration
Create a collaboration request from a campaign and creator profile. Only participants can read messages. Add notification delivery, abuse reporting, block controls and retention policies.

## Payments
Create checkout sessions server-side. Use signed webhooks to confirm payment state. Keep platform fee, tax, currency conversion, refunds and chargebacks explicit. Never store card details yourself.

## Trust and safety
Add email verification, creator/business verification, review eligibility checks, campaign moderation, content reporting, dispute handling, fraud detection and audit logging.
