# INFLUENCER.COM — Global Influencer Marketplace

A comprehensive full-stack starter for a worldwide influencer/brand marketplace. It includes a polished Next.js UI, creator directory, filters, creator profiles, sample video showcase, campaign board, signup/login wiring for Supabase, dashboard/admin scaffolds, API health route and an initial relational schema with Row Level Security policies.

## Important: what is and is not live
This ZIP is a working development foundation, not a production marketplace that is already connected to every provider. Sample creators, follower numbers, ratings, prices, campaigns and videos are demonstration content only. They are not verified accounts or live metrics.

Real social account connections and current audience statistics require each platform's official OAuth/API access, approved app permissions, token handling, rate-limit compliance and review. Payment processing requires a payment provider account, webhook verification, local legal/tax review and a secure server-side implementation. The starter deliberately does not fake these integrations.

## Requirements
- Node.js 20.10+ recommended
- npm
- Supabase project (only needed for real account registration/login and database)

## Run locally
1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal in this folder.
4. Run `npm install`
5. Copy `.env.example` to `.env.local`.
6. Add your Supabase Project URL and anon key to `.env.local` (or leave them blank to explore demo mode).
7. In Supabase SQL Editor, run `supabase/schema.sql`.
8. Run `npm run dev`
9. Open `http://localhost:3000`

## Included screens
- `/` — landing page
- `/discover` — creator directory with text, category, country and platform filters
- `/creator/c1` etc. — creator profile and demo video
- `/campaigns` — campaign listings
- `/how-it-works`
- `/register` and `/login` — Supabase Auth wiring (requires env)
- `/dashboard` — workspace layout scaffold
- `/admin` — moderation/admin scaffold; must be protected before deployment
- `/contact` — enquiry flow preview
- `/privacy` and `/terms` — legal draft placeholders
- `/api/health` — health endpoint

## 15-step delivery map
1. Project setup and architecture — included.
2. Design system and responsive navigation — included.
3. Homepage and discovery landing — included.
4. Authentication wiring — Supabase Auth starter included; production redirects/session handling still needed.
5. Creator registration/profile — role-aware signup included; profile completion UI and server persistence to implement.
6. Business registration/profile — role-aware signup included; business profile completion UI and persistence to implement.
7. Database — initial schema and RLS included in `supabase/schema.sql`; test policies before production.
8. Creator profiles — sample profile pages included; connect to database for live data.
9. Video marketplace — sample video showcase included; upload/storage moderation still needed.
10. Social integrations — provider connection placeholders and env names; official OAuth flows require provider app approval.
11. Advanced search — demo category/country/platform filters; production distance and metric filters need geocoding/data.
12. Smart matching — data model foundation; ranking algorithm to implement and validate with real campaign data.
13. Collaboration and messaging — schema and enquiry UI foundation; real-time messaging and notifications to implement.
14. Payments and admin — schema and admin UI scaffold; secure payment provider integration/webhooks and admin authorization required.
15. Testing and production deployment — local run setup included; automated tests, security audit, monitoring and deployment configuration remain before launch.

## Before launch checklist
- Add server-side Supabase session handling and protect private routes.
- Validate every input on the server; never trust client-supplied role, rate, rating or follower data.
- Review every RLS policy against real user roles and test cross-account access.
- Store OAuth tokens securely on the server; never expose secrets to the browser.
- Use official APIs only and clearly label stale/unavailable metrics.
- Add moderation, reporting, takedown and dispute workflows.
- Implement verified payment webhooks; never mark payments successful from the browser.
- Add rate limiting, audit logs, backups, monitoring and automated tests.
- Replace sample content and draft legal pages with reviewed production content.
