export type Creator = {
  id: string; name: string; handle: string; country: string; city: string;
  category: string; platforms: string[]; followers: string; engagement: string;
  rate: string; rating: number; bio: string; languages: string[];
  avatar: string; cover: string; verified: boolean; video: string;
};
export type Campaign = {
  id: string; title: string; brand: string; category: string; location: string;
  budget: string; description: string; status: "Open" | "Draft" | "Closed";
};
