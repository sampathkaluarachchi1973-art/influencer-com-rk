import Link from "next/link";
import { ArrowUpRight, Globe2, ShieldCheck, Zap, Play, Users, TrendingUp } from "lucide-react";
import CreatorCard from "@/components/CreatorCard";
import { creators, categories } from "@/lib/data";
export default function Home(){
 return <main>
  <section className="relative overflow-hidden pb-16 pt-20 md:pt-28">
   <div className="pointer-events-none absolute -right-40 -top-40 h-[550px] w-[550px] rounded-full bg-violet-600/15 blur-[120px]"/>
   <div className="container relative grid items-center gap-12 lg:grid-cols-[1.1fr_.9fr]">
    <div><span className="pill inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-green-400"/> THE GLOBAL CREATOR ECONOMY</span>
     <h1 className="mt-6 max-w-3xl text-5xl font-black leading-[1.08] tracking-tight md:text-7xl">Find your next <span className="text-[#aa9dff]">creative</span> partnership.</h1>
     <p className="mt-6 max-w-xl text-lg leading-8 text-[#a8a9b8]">One marketplace for brands to discover trusted influencers, compare real performance and launch collaborations anywhere in the world.</p>
     <div className="mt-8 flex flex-wrap gap-3"><Link href="/discover" className="btn btn-primary">Explore creators <ArrowUpRight size={17}/></Link><Link href="/register?type=business" className="btn btn-outline">I’m a brand</Link></div>
     <div className="mt-10 flex flex-wrap gap-8 text-sm text-[#a8a9b8]"><span className="flex items-center gap-2"><Globe2 size={17}/> Global discovery</span><span className="flex items-center gap-2"><ShieldCheck size={17}/> Trust-focused profiles</span><span className="flex items-center gap-2"><Zap size={17}/> Faster campaigns</span></div>
    </div>
    <div className="relative"><div className="absolute inset-5 rounded-[32px] bg-violet-500/20 blur-3xl"/><div className="glass relative rounded-[28px] p-4 shadow-glow">
     <div className="flex items-center justify-between px-2 py-3"><div><p className="text-sm text-[#a3a4b4]">Creator spotlight</p><b>Creators to watch</b></div><span className="pill">Worldwide</span></div>
     {creators.slice(0,3).map((c,i)=><div key={c.id} className="flex items-center gap-4 border-t border-white/10 p-3"><img src={c.avatar} alt="" className="h-14 w-14 rounded-xl object-cover"/><div className="min-w-0 flex-1"><b>{c.name}</b><p className="text-xs text-[#9b9cad]">{c.category} · {c.country}</p></div><div className="text-right"><b>{c.followers}</b><p className="text-xs text-[#9b9cad]">followers</p></div></div>)}
     <div className="mt-3 rounded-2xl bg-[#25283a] p-4"><div className="flex items-center gap-2 text-sm"><TrendingUp size={16} className="text-green-400"/> Smarter creator matching</div><p className="mt-1 text-xs text-[#a8a9b8]">Find creators based on audience, category, location and campaign goals.</p></div>
    </div></div>
   </div>
  </section>
  <section className="section border-y border-white/5 bg-[#141722]"><div className="container"><div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div><p className="text-sm font-bold uppercase tracking-[.2em] text-[#a99cff]">Discover talent</p><h2 className="mt-2 text-3xl font-bold">Creators worth knowing</h2></div><Link href="/discover" className="text-sm text-[#b6aaff]">Browse all creators →</Link></div><div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{creators.slice(0,3).map(c=><CreatorCard key={c.id} creator={c}/>)}</div></div></section>
  <section className="section"><div className="container"><div className="mx-auto max-w-2xl text-center"><p className="text-sm font-bold uppercase tracking-[.2em] text-[#a99cff]">One platform, two sides</p><h2 className="mt-2 text-3xl font-bold">Make every collaboration count</h2><p className="mt-4 text-[#a8a9b8]">Whether you’re growing a brand or building an audience, INFLUENCER.COM brings the workflow together.</p></div><div className="mt-10 grid gap-5 md:grid-cols-2"><div className="card p-8"><Users className="text-[#b3a8ff]"/><h3 className="mt-5 text-xl font-bold">For businesses</h3><p className="mt-2 text-sm leading-6 text-[#a8a9b8]">Search creators by market, niche, audience size and performance. Publish campaigns and manage collaboration requests in one place.</p><Link href="/register?type=business" className="mt-6 inline-block text-sm font-bold text-[#b3a8ff]">Create a brand account →</Link></div><div className="card p-8"><Play className="text-[#b3a8ff]"/><h3 className="mt-5 text-xl font-bold">For influencers</h3><p className="mt-2 text-sm leading-6 text-[#a8a9b8]">Build a professional creator profile, showcase your content, list your services and connect with brands that fit your audience.</p><Link href="/register?type=creator" className="mt-6 inline-block text-sm font-bold text-[#b3a8ff]">Join as a creator →</Link></div></div></div></section>
  <section className="pb-20"><div className="container rounded-3xl bg-gradient-to-r from-[#282342] to-[#202b3b] p-8 md:p-12"><div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center"><div><h2 className="text-3xl font-bold">Your next campaign starts here.</h2><p className="mt-2 text-[#b6b5c7]">Join the creator economy with INFLUENCER.COM.</p></div><Link href="/register" className="btn btn-primary">Get started <ArrowUpRight size={17}/></Link></div></div></section>
 </main>
}
