 "use client";
import { useMemo, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import CreatorCard from "@/components/CreatorCard";
import { creators, categories } from "@/lib/data";
export default function Discover(){
 const [query,setQuery]=useState(""); const [category,setCategory]=useState("All"); const [country,setCountry]=useState("All countries"); const [platform,setPlatform]=useState("All platforms");
 const filtered=useMemo(()=>creators.filter(c=>(category==="All"||c.category===category)&&(country==="All countries"||c.country===country)&&(platform==="All platforms"||c.platforms.includes(platform))&&(`${c.name} ${c.city} ${c.country} ${c.category} ${c.handle}`).toLowerCase().includes(query.toLowerCase())),[query,category,country,platform]);
 return <main className="container min-h-[75vh] py-12"><p className="text-sm font-bold uppercase tracking-[.2em] text-[#a99cff]">Creator directory</p><h1 className="mt-2 text-4xl font-black">Discover creators</h1><p className="mt-3 text-[#a8a9b8]">Explore creator profiles and narrow down your perfect campaign match.</p>
 <div className="glass mt-8 grid gap-3 rounded-2xl p-4 md:grid-cols-[1fr_190px_190px]"><div className="relative"><Search className="absolute left-3 top-3.5 text-[#8f90a1]" size={18}/><input className="field pl-10" placeholder="Search name, city, category..." value={query} onChange={e=>setQuery(e.target.value)}/></div><select className="field" value={country} onChange={e=>setCountry(e.target.value)}><option>All countries</option>{Array.from(new Set(creators.map(c=>c.country))).map(x=><option key={x}>{x}</option>)}</select><select className="field" value={platform} onChange={e=>setPlatform(e.target.value)}><option>All platforms</option>{["Instagram","TikTok","YouTube","Facebook"].map(x=><option key={x}>{x}</option>)}</select></div>
 <div className="my-5 flex flex-wrap gap-2">{categories.map(x=><button key={x} onClick={()=>setCategory(x)} className={`pill ${category===x?"border-[#9b8cff] bg-[#9b8cff]/15 text-white":""}`}>{x}</button>)}</div>
 <div className="mb-4 flex items-center justify-between text-sm text-[#a8a9b8]"><span>{filtered.length} creators found</span><span className="flex items-center gap-2"><SlidersHorizontal size={15}/> Filters</span></div>
 {filtered.length?<div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{filtered.map(c=><CreatorCard key={c.id} creator={c}/>)}</div>:<div className="card p-12 text-center text-[#a8a9b8]">No matching creators found. Try changing your search or filters.</div>}
 </main>
}
