import Link from "next/link";
import { Menu } from "lucide-react";
export default function Navbar(){
 return <header className="sticky top-0 z-50 border-b border-white/10 bg-[#10121a]/90 backdrop-blur-xl">
  <div className="container flex h-[72px] items-center justify-between">
   <Link href="/" className="flex items-center gap-2 text-xl font-black tracking-tight"><span className="grid h-9 w-9 place-items-center rounded-xl gradient text-black text-sm font-black">RK</span><span>INFLUENCER.COM</span></Link>
   <nav className="hidden items-center gap-7 text-sm text-[#c4c4d0] md:flex"><Link href="/discover">Discover</Link><Link href="/campaigns">Campaigns</Link><Link href="/how-it-works">How it works</Link></nav>
   <div className="flex items-center gap-2"><Link className="btn btn-outline text-sm" href="/login">Log in</Link><Link className="btn btn-primary text-sm" href="/register">Get started</Link></div>
  </div>
 </header>
}
