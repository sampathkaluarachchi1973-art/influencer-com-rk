import Link from "next/link";
import { MapPin, Star, BadgeCheck } from "lucide-react";
import type { Creator } from "@/lib/types";
export default function CreatorCard({creator}:{creator:Creator}){
 return <Link href={`/creator/${creator.id}`} className="card group block transition hover:-translate-y-1 hover:border-[#9b8cff]/60">
  <div className="relative h-36 bg-cover bg-center" style={{backgroundImage:`linear-gradient(0deg,#191c28,transparent),url(${creator.cover})`}}>
   <img src={creator.avatar} alt={creator.name} className="absolute -bottom-8 left-5 h-16 w-16 rounded-2xl border-4 border-[#191c28] object-cover"/>
   <span className="pill absolute right-4 top-4 bg-black/40">{creator.category}</span>
  </div>
  <div className="p-5 pt-11"><div className="flex items-center gap-2 font-bold">{creator.name}{creator.verified&&<BadgeCheck size={16} className="text-[#9b8cff]"/>}</div><p className="text-sm text-[#9b9cad]">{creator.handle}</p><p className="mt-3 flex items-center gap-1 text-xs text-[#b9b9c7]"><MapPin size={13}/>{creator.city}, {creator.country}</p>
   <div className="mt-4 grid grid-cols-3 gap-2 border-y border-white/10 py-3 text-center"><div><b>{creator.followers}</b><p className="text-[11px] text-[#999aaa]">Followers</p></div><div><b>{creator.engagement}</b><p className="text-[11px] text-[#999aaa]">Engagement</p></div><div className="flex flex-col items-center"><b className="flex items-center gap-1"><Star size={12} className="text-yellow-400"/>{creator.rating}</b><p className="text-[11px] text-[#999aaa]">Rating</p></div></div>
   <div className="mt-4 flex items-center justify-between"><span className="text-sm text-[#bdbdcc]">From <b className="text-white">{creator.rate}</b></span><span className="text-sm font-semibold text-[#b4a9ff]">View profile →</span></div>
  </div>
 </Link>
}
