-- INFLUENCER.COM initial Supabase schema.
-- Run in Supabase SQL Editor after creating a project.
create extension if not exists "pgcrypto";

create type public.account_type as enum ('creator','business','admin');
create type public.campaign_status as enum ('draft','open','paused','closed','completed');
create type public.collaboration_status as enum ('requested','accepted','declined','in_progress','completed','cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  account_type public.account_type not null default 'creator',
  display_name text not null,
  email text,
  country text,
  city text,
  bio text,
  website text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.creator_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  handle text unique,
  categories text[] not null default '{}',
  languages text[] not null default '{}',
  base_rate numeric(12,2),
  currency char(3) default 'USD',
  verified boolean not null default false
);
create table public.social_accounts (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  platform text not null check (platform in ('youtube','tiktok','instagram','facebook')),
  platform_user_id text,
  username text,
  profile_url text,
  follower_count bigint,
  engagement_rate numeric(7,3),
  last_synced_at timestamptz,
  token_reference text, -- Store encrypted token references server-side; never expose tokens.
  unique(creator_id, platform, platform_user_id)
);
create table public.creator_videos (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  video_url text not null,
  thumbnail_url text,
  platform text,
  published_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  category text,
  country text,
  city text,
  budget_min numeric(12,2),
  budget_max numeric(12,2),
  currency char(3) default 'USD',
  description text not null,
  requirements jsonb not null default '{}'::jsonb,
  status public.campaign_status not null default 'draft',
  created_at timestamptz not null default now()
);
create table public.collaborations (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid references public.campaigns(id) on delete set null,
  business_id uuid not null references public.profiles(id) on delete cascade,
  creator_id uuid not null references public.profiles(id) on delete cascade,
  proposal text,
  agreed_amount numeric(12,2),
  currency char(3) default 'USD',
  status public.collaboration_status not null default 'requested',
  created_at timestamptz not null default now()
);
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  collaboration_id uuid not null references public.collaborations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  collaboration_id uuid not null references public.collaborations(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete cascade,
  reviewee_id uuid not null references public.profiles(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique(collaboration_id, reviewer_id)
);
create table public.payment_records (
  id uuid primary key default gen_random_uuid(),
  collaboration_id uuid not null references public.collaborations(id) on delete restrict,
  provider text not null,
  provider_reference text unique,
  amount numeric(12,2) not null,
  currency char(3) not null,
  status text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.creator_profiles enable row level security;
alter table public.social_accounts enable row level security;
alter table public.creator_videos enable row level security;
alter table public.campaigns enable row level security;
alter table public.collaborations enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
alter table public.payment_records enable row level security;

-- Public profile discovery; users may update only their own profile.
create policy "profiles are viewable" on public.profiles for select using (true);
create policy "users insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "users update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "creator profile public read" on public.creator_profiles for select using (true);
create policy "creator owns creator profile" on public.creator_profiles for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "social account public read" on public.social_accounts for select using (true);
create policy "creator manages own social accounts" on public.social_accounts for all using (auth.uid() = creator_id) with check (auth.uid() = creator_id);
create policy "creator videos public read" on public.creator_videos for select using (true);
create policy "creator manages own videos" on public.creator_videos for all using (auth.uid() = creator_id) with check (auth.uid() = creator_id);
create policy "open campaigns public read" on public.campaigns for select using (status = 'open' or auth.uid() = business_id);
create policy "business manages own campaigns" on public.campaigns for all using (auth.uid() = business_id) with check (auth.uid() = business_id);
create policy "collaboration participants read" on public.collaborations for select using (auth.uid() = business_id or auth.uid() = creator_id);
create policy "business can request collaboration" on public.collaborations for insert with check (auth.uid() = business_id);
create policy "participants update collaboration" on public.collaborations for update using (auth.uid() = business_id or auth.uid() = creator_id);
create policy "message participants read" on public.messages for select using (
 exists(select 1 from public.collaborations c where c.id=collaboration_id and (c.business_id=auth.uid() or c.creator_id=auth.uid()))
);
create policy "participants send messages" on public.messages for insert with check (
 auth.uid() = sender_id and exists(select 1 from public.collaborations c where c.id=collaboration_id and (c.business_id=auth.uid() or c.creator_id=auth.uid()))
);
create policy "reviews public read" on public.reviews for select using (true);
create policy "participants create reviews" on public.reviews for insert with check (auth.uid() = reviewer_id and exists(select 1 from public.collaborations c where c.id=collaboration_id and c.status='completed' and (c.business_id=auth.uid() or c.creator_id=auth.uid())));
create policy "payment records participant read" on public.payment_records for select using (
 exists(select 1 from public.collaborations c where c.id=collaboration_id and (c.business_id=auth.uid() or c.creator_id=auth.uid()))
);
-- Payment rows must be written only by trusted server/webhook using service role.
