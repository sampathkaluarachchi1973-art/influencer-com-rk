import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { ink: "#10121a", panel: "#181b26", accent: "#9b8cff" }, boxShadow: { glow: "0 0 40px rgba(155,140,255,.18)" } } },
  plugins: []
};
export default config;
